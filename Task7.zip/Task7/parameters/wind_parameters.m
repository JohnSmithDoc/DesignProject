
% wind parameters
WIND.wind_n = 3;
WIND.wind_e = 2;
WIND.wind_d = 0;
WIND.L_u = 200;
WIND.L_v = 200;
WIND.L_w = 50;
WIND.sigma_u = 1.06; 
WIND.sigma_v = 1.06;
WIND.sigma_w = 0.7;

WIND.Va0 = 25;
